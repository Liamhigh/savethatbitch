# Verum Omnis v2 - Forensic Engine

Verum Omnis is a powerful, stateless, and secure forensic analysis engine. It leverages the Google Gemini API to perform deep analysis on legal documents, images, and other evidence, producing comprehensive, court-ready forensic reports.

Built as a Progressive Web App (PWA), it runs entirely on-device, ensuring user data is never uploaded or stored on external servers. It is designed for cross-platform use, functioning seamlessly in modern web browsers and as a native Android application via Capacitor.

## Key Features

-   **On-Device AI Processing:** All analysis is performed securely in the browser, guaranteeing privacy and confidentiality.
-   **Multi-modal Evidence Analysis:** Supports a wide range of file types including text, `.txt`, `.pdf`, and common image formats (`.png`, `.jpg`, etc.).
-   **Dynamic Model Selection:** Automatically utilizes `gemini-2.5-flash` for general cases and `gemini-2.5-pro` with an enhanced thinking budget for more complex evidence like PDFs.
-   **Structured Forensic Reports:** Generates highly-structured reports in Markdown, detailing executive summaries, timelines, liability assessments, strategic recommendations, and more.
-   **Cryptographically Sealed PDFs:** Allows users to download reports as PDFs secured with a SHA-256 cryptographic seal, verifying the document's integrity.
-   **Offline-First & Installable:** Fully functional without an internet connection for case preparation. It can be installed on any device as a PWA.
-   **Production Ready:** Configured for robust deployment on Firebase Hosting and for building into a native Android application with Capacitor.

## Tech Stack

-   **Frontend:** React, TypeScript, Vite
-   **AI:** Google Gemini API (`@google/genai`)
-   **PDF Generation:** jsPDF
-   **Native Runtime:** Capacitor
-   **Hosting:** Firebase Hosting
-   **CI/CD:** GitHub Actions

## Getting Started

### Prerequisites

-   Node.js (v18 or later)
-   npm (v8 or later)
-   For Android development: Android Studio and Android SDK installed and configured.

### Local Development

1.  **Clone the Repository:**
    ```bash
    git clone https://github.com/liamhigh/verum-omnis-v2.git
    cd verum-omnis-v2
    ```

2.  **Install Dependencies:**
    ```bash
    npm install
    ```

3.  **API Key Configuration:**
    Create a `.env` file in the project root by copying the `.env.example` file:
    ```bash
    cp .env.example .env
    ```
    Open the new `.env` file and add your Google Gemini API key:
    ```
    VITE_API_KEY="YOUR_GEMINI_API_KEY_HERE"
    ```

4.  **Run the Development Server:**
    ```bash
    npm run dev
    ```
    The application will be available at `http://localhost:5173`.

## Build and Deployment

### Production Web Build

To create an optimized production build of the web app:

```bash
npm run build
```

The output files will be generated in the `dist/` directory.

### Firebase Hosting

This project is configured for continuous deployment to Firebase Hosting. Every push to the `main` branch triggers the GitHub Actions workflow defined in `.github/workflows/firebase-hosting.yml`.

For the workflow to succeed, you must configure the following secrets in your GitHub repository settings:
-   `VITE_API_KEY`: Your Google Gemini API key.
-   `FIREBASE_SERVICE_ACCOUNT_VERUM_OMNIS_V2`: The JSON content of your Firebase service account key for the `verum-omnis-v2` project.

## Mobile Development (Capacitor)

### Simplified NPM Scripts

A few scripts have been added to `package.json` to streamline the process of building and running the application as a native Android app.

1.  **Add the Android Platform (One-Time Setup):**
    This only needs to be done once to create the native Android project in the `android/` directory.
    ```bash
    npm run android:setup
    ```

2.  **Sync Web Assets with Android Project:**
    This command copies your latest web build from `dist/` into the native Android project. Run this command every time you update your web code.
    ```bash
    npm run android:sync
    ```

3.  **Build a Debug APK:**
    This command bundles the previous steps and builds a debug-ready APK located in `android/app/build/outputs/apk/debug/`.
    ```bash
    npm run android:build:debug
    ```

4.  **Open in Android Studio:**
    To run the app on an emulator or a connected physical device, open the project in Android Studio.
    ```bash
    npm run android:open
    ```

## Contributing

Contributions are welcome. Please open an issue to discuss any changes or submit a pull request with a clear description of your improvements.

## License

This project is licensed under the MIT License.
